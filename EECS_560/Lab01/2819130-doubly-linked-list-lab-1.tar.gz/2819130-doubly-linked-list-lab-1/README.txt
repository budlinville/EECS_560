NOTE: This program does not require, but does permit, a command-line parameter corresponding
      to the file that the user would like to use for building a doubly linked list.

      Use the format provided in the data.txt file
