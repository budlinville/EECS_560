#include "list.hpp"
#include "util.hpp"

DoublyLinkedList::DoublyLinkedList() {
  //IMPLEMENT ME
  implMe();
}

DoublyLinkedList::~DoublyLinkedList() {
  //IMPLEMENT ME
  implMe();
}

bool DoublyLinkedList::isEmpty() {
  //IMPLEMENT ME
  implMe();
  return true;
}

int DoublyLinkedList::size(){
  //IMPLEMENT ME
  implMe();
  return true;
}

void DoublyLinkedList::add(int elem, int position) {
  //IMPLEMENT ME
  implMe();
}

void DoublyLinkedList::deleteAll(int elem) {
  //IMPLEMENT ME
  implMe();
}

int DoublyLinkedList::find(int elem) {
  //IMPLEMENT ME
  implMe();
  return -1;
}

void DoublyLinkedList::print() {
  implMe();
  //IMPLEMENT ME
}
