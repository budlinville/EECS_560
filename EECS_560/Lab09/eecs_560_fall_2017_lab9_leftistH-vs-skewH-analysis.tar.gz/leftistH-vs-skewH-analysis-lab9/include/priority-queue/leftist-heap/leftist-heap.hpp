#ifndef LEFTIST_HEAP_HPP
#define LEFTIST_HEAP_HPP

class LeftistHeap{

};

#endif //LEFTIST_HEAP_HPP defined
