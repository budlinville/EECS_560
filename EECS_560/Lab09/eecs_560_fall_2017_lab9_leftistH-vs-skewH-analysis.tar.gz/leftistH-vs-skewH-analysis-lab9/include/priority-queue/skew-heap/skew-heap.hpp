#ifndef SKEW_HEAP_HPP
#define SKEW_HEAP_HPP

class SkewHeap{

};

#endif //SKEW_HEAP_HPP defined
