#include "disjoint-set.hpp"
#include "util.hpp"

DisjointSet::DisjointSet(int size) {
  IMPLEMENT_ME();
}

int DisjointSet::find(int elem) {
  IMPLEMENT_ME();
  return -1;
}
void DisjointSet::union_set(int a, int b) {
  IMPLEMENT_ME();
}


void DisjointSet::print() {
    IMPLEMENT_ME();
}
