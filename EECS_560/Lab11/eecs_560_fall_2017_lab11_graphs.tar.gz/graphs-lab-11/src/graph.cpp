#include "graph.hpp"
#include "util/util.hpp"

Graph::Graph(int** costs, int n){
  IMPLEMENT_ME();
}

DoublyLinkedList** Graph::dfs() {
  DoublyLinkedList** edge_set = new DoublyLinkedList*[2];
  IMPLEMENT_ME();
  return edge_set;
}


DoublyLinkedList** Graph::bfs() {
  DoublyLinkedList** edge_set = new DoublyLinkedList*[2];
  IMPLEMENT_ME();
  return edge_set;
}

DoublyLinkedList* Graph::kruskal() {
  IMPLEMENT_ME();
  return new DoublyLinkedList();
}

DoublyLinkedList* Graph::prim(){
  IMPLEMENT_ME();
  return new DoublyLinkedList();
}
