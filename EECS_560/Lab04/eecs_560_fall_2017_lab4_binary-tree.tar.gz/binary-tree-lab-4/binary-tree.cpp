
#include "binary-tree.hpp"
#include "util.hpp"

BinaryTree::BinaryTree(){
  IMPLEMENT_ME();
}

BinaryTree::~BinaryTree() {
  IMPLEMENT_ME();
}

void BinaryTree::addElem(int elem) {
  IMPLEMENT_ME();
}

int BinaryTree::deleteElem() {
  IMPLEMENT_ME();
  return 0;
}

bool BinaryTree::exists(int elem) {
  IMPLEMENT_ME();
  return false;
}

int BinaryTree::inorderTraverse(int identity, int (*operation)(int, int)){
  IMPLEMENT_ME();
  return 0;
}

int BinaryTree::preorderTraverse(int identity, int (*operation)(int, int)){
  IMPLEMENT_ME();
  return 0;
}

int BinaryTree::postorderTraverse(int identity, int (*operation)(int, int)){
  IMPLEMENT_ME();
  return 0;
}

int BinaryTree::sum(){
  IMPLEMENT_ME();
  return 0;
}

void BinaryTree::print(int printType) {
  if(printType == 1){
    std::cout << "inorder traversal: " << std::endl;
    IMPLEMENT_ME();
  }
  else if(printType == 2){
    std::cout << "preorder traversal: " << std::endl;
    IMPLEMENT_ME();
  } else if(printType == 3){
    std::cout << "postorder traversal: " << std::endl;
    IMPLEMENT_ME();
  } else {
    std::cout << "Error invalid print type. Please choose a correct option."
              << std::endl;
  }
}
