#include "minmax-heap.hpp"
#include "../util/util.hpp"


//////////////////////////////////
// Private Functions Definition //
//////////////////////////////////
void MinMaxHeap::buildHeap(){
  IMPLEMENT_ME();
}

/////////////////////////////////
// Public functions definition //
/////////////////////////////////

MinMaxHeap::MinMaxHeap(){
  IMPLEMENT_ME();
}

MinMaxHeap::MinMaxHeap(std::string * elems, int size){
  IMPLEMENT_ME();
}

MinMaxHeap::~MinMaxHeap() {
  IMPLEMENT_ME();
}

void MinMaxHeap::addElem(std::string elem) {
  IMPLEMENT_ME();
}

void MinMaxHeap::deleteElem(std::string elem) {
  IMPLEMENT_ME();
}

int MinMaxHeap::size(){
  IMPLEMENT_ME();
  return 0;
}

bool MinMaxHeap::exists(std::string elem){
  IMPLEMENT_ME();
  return false;
}

std::string MinMaxHeap::deleteMinElem(){
  IMPLEMENT_ME();
  return "";
}

std::string MinMaxHeap::deleteMaxElem(){
  IMPLEMENT_ME();
  return "";
}

void MinMaxHeap::levelOrderPrint(){
  IMPLEMENT_ME();
}
