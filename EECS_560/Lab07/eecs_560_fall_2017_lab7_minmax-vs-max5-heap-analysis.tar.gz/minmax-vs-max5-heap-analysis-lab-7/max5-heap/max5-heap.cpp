#include "max5-heap.hpp"
#include "../util/util.hpp"


//////////////////////////////////
// Private Functions Definition //
//////////////////////////////////
void Max5Heap::buildHeap(){
  IMPLEMENT_ME();
}

/////////////////////////////////
// Public functions definition //
/////////////////////////////////

Max5Heap::Max5Heap(){
  IMPLEMENT_ME();
}

Max5Heap::Max5Heap(std::string * elems, int size){
  IMPLEMENT_ME();
}

Max5Heap::~Max5Heap() {
  IMPLEMENT_ME();
}

void Max5Heap::addElem(std::string elem) {
  IMPLEMENT_ME();
}

void Max5Heap::deleteElem(std::string elem) {
  IMPLEMENT_ME();
}

int Max5Heap::size(){
  IMPLEMENT_ME();
  return 0;
}

bool Max5Heap::exists(std::string elem){
  IMPLEMENT_ME();
  return false;
}

std::string Max5Heap::deleteMinElem(){
  IMPLEMENT_ME();
  return "";
}

std::string Max5Heap::deleteMaxElem(){
  IMPLEMENT_ME();
  return "";
}

void Max5Heap::levelOrderPrint(){
  IMPLEMENT_ME();
}
