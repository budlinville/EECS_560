/////////////////////////////////////////////////////////
// THIS FILE DEFINES ALL THE METHODS TO BE IMPLEMENTED //
// PLEASE GET RID OF ALL THE IMPLEMENT_ME() FUNCTIONS  //
/////////////////////////////////////////////////////////

#include "util.hpp"
#include "hash-table.hpp"


using namespace std;

HashTable::HashTable(int size){
  //cout << "creating a store with size " << size << endl;
  this->size = size;
  IMPLEMENT_ME();
}

int HashTable::hash(string value){
  IMPLEMENT_ME();
  return 0;
}

void HashTable::resize(){
  IMPLEMENT_ME();
}

void HashTable::putValue(string elem){
  //cout << "adding value " << elem << endl;
  IMPLEMENT_ME();
}

bool HashTable::searchValue(string elem){
  //cout << "seraching for value " << elem << endl;
  IMPLEMENT_ME();
  return false;
}

void HashTable::deleteValue(string elem){
  //cout << "deleting value " << elem << endl;
  IMPLEMENT_ME();
}

void HashTable::print(){
  IMPLEMENT_ME();
}
