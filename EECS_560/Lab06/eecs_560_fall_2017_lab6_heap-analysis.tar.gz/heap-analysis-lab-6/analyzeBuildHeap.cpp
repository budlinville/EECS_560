#include <iostream>
#include <fstream>

#include "timer.hpp"
#include "min3-heap.hpp"
#include "util.hpp"

using namespace std;

int  main() {
  Timer* t = new Timer();

  t->start();
  IMPLEMENT_ME();
  std::cout << "operation took: ";
  t->printTime(t->stop());

  delete t;
  return 0;
}
