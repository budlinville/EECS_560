#include "min3-heap.hpp"
#include "util.hpp"


//////////////////////////////////
// Private Functions Definition //
//////////////////////////////////
void Min3Heap::buildHeap(){
  IMPLEMENT_ME();
}

/////////////////////////////////
// Public functions definition //
/////////////////////////////////

Min3Heap::Min3Heap(){
  IMPLEMENT_ME();
}

Min3Heap::Min3Heap(std::string *){
  IMPLEMENT_ME();
}


Min3Heap::~Min3Heap() {
  IMPLEMENT_ME();
}

void Min3Heap::addElem(std::string elem) {
  IMPLEMENT_ME();
}

void Min3Heap::deleteElem(std::string elem) {
  IMPLEMENT_ME();
}

bool Min3Heap::exists(std::string elem){
  IMPLEMENT_ME();
  return false;
}

std::string Min3Heap::deleteMinElem(){
  IMPLEMENT_ME();
  return "";
}

std::string Min3Heap::deleteMaxElem(){
  IMPLEMENT_ME();
  return "";
}


void Min3Heap::levelOrderPrint(){
  IMPLEMENT_ME();
}
