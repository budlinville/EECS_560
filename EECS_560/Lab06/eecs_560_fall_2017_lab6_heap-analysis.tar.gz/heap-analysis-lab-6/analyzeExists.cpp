#include <iostream>
#include "timer.hpp"
#include "min3-heap.hpp"
#include "util.hpp"

int  main() {
  Timer* t = new Timer();

  t->start();
  IMPLEMENT_ME();
  std::cout << "operation took: ";
  t->printTime(t->stop());

  return 0;
}
